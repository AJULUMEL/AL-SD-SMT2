

public class Node06 {
    TransaksiPajak06 data;
    Node06 prev;
    Node06 next;

    public Node06(TransaksiPajak06 data) {
        this.data = data;
    }
}
